import React from 'react';
import './Header.css';

const Header = () => {
    return (
        <h1 className='Header__title'>React Users</h1>
    )
}

export { Header };