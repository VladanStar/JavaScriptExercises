import React from 'react';
import './Footer.css'

const Footer = () => {
    return (
        <p className="Footer__copyright">&#169;2020 Copyright BIT | All rights reserved.</p>
    )
}

export { Footer }